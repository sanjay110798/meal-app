# the_Meal_App
🪧 Demo :- https://susmita-biswas70.github.io/the_Meal_App/

About the Project :-

🔴 This is a single page website where you can seach about any meal.

🔴 You can also add it into on your favourite list.

🔴 The most important thing about this project it is fully responsive of nature and use an api called the themealdb to fetch all the dishes.

🔴 It also redirects users to a youtube videos for the recipe of dishes.

 Built With :-

🟠 HTML 🟠 Pure CSS 🟠 Vanilla Javascript 🟠 Bootstrap
